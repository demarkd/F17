const char *GFAN_RELEASEDIR="gfan0.6.2"; const char *GFAN_FORKTIME=
"1506606121 Thu Sep 28 15:42:01 2017"
;
