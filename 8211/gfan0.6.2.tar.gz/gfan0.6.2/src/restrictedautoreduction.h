#ifndef RESTRICTEDAUTOREDUCTION_H_INCLUDED
#define RESTRICTEDAUTOREDUCTION_H_INCLUDED

#include "polynomial.h"

void autoReduceRestricted(PolynomialSet *g, PolynomialSet const &initialIdeal);

#endif
