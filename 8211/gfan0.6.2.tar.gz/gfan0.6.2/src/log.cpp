#include "log.h"

int logLevel;

void setLogLevel(int l)
{
  logLevel=l;
}
