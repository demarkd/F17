#ifndef LATTICEIDEAL_H_INCLUDED
#define LATTICEIDEAL_H_INCLUDED

#include "matrix.h"

IntegerVectorList latticeIdealRevLex(IntegerMatrix const &lattice);

#endif
