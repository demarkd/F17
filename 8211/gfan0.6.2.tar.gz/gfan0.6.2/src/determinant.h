#ifndef DETERMINANT_H_INCLUDED
#define DETERMINANT_H_INCLUDED
#include "vektor.h"

int determinantSign(IntegerVectorList const &v);

#endif
