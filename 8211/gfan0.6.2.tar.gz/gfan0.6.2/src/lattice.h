#include "vektor.h"

bool isPartOfAZBasis(IntegerVectorList const &l);
