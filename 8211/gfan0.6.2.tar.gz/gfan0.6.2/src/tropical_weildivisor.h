#include "polyhedralfan.h"

//PolyhedralFan weilDivisor(PolyhedralFan const &F, Polynomial const &f);
PolyhedralFan weilDivisor(PolyhedralFan const &F, PolyhedralFan const &G);//, Polynomial const &g)
